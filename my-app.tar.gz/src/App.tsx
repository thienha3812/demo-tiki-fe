import React from 'react';
import logo from './logo.svg';
import './App.css';
import 'antd/dist/antd.css'; // or 'antd/dist/antd.less'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import NavBar from './components/navbar';
import HomePage from './containers/home-page';
function App() {
  return (
    <div className="App">
      <Router>
          <NavBar/>
          <HomePage />
      </Router>
    </div>
  );
}

export default App;
