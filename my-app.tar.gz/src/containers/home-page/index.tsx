import React from 'react'
import styled from 'styled-components'



const List = styled.ul`
    list-style-type:none;
    border: 1px solid #e6e6e6;
    border-radius:5px;
`

const ListItem = styled.li`
    font-weight:400;
    font-size:14px;
    color: rgb(68, 68, 68);
    font-weight:400px;
    height:30px;
    line-height:30px;

`



const HomePage = (props :any) => {
    const lists = [
        {
            title:"Điện Thoại - Máy Tính Bảng"
        },
        {
            title:"Điện tử - Điện Lạnh"
        },
        {
            title: "Phụ kiện - Thiết Bị Số"
        },
        {
            title: "Laptop - Thiết bị IT"
        },
        {
            title: "Máy ảnh - Quay Phim"
        },
        {
            title: "Điện Gia Dụng"
        },
        {
            title: "Nhà Cửa Đời Sống"
        },
        {
            title: "Hàng Tiêu Dùng - Thực Phẩm"
        },
        {
            title: "Đồ chơi, Mẹ & Bé"
        },
        {
            title: "Làm Đẹp - Sức Khỏe"
        },
        {
            title: "Thời Trang - Phụ Kiện"
        },
        {
            title: "Thể thao - Dã Ngoại"
        },
        {
            title: "Xe máy, Ô tô, Xe Đạp"
        },
        {
            title: "Hàng quốc tế"
        },
        {
            title: "Sách, VPP & Quà Tặng"
        },
        {
            title: "Voucher - Dịch vụ - Thẻ cào"
        }
    ]
    return (
        <React.Fragment>
                <div style={{width:'100%',display:'flex',justifyContent:"center"}}>
                    <div style={{width:'15%'}}>
                        <List>
                        {lists.map(item => ( 
                            <ListItem>{item.title}</ListItem>
                        ))}
                        </List>
                    </div>
                    <div style={{width:'55%',height:"auto"}}>
                            <div style={{display:"flex",flexDirection:"row"}}>
                                <div style={{width:"50%",height:"66%",backgroundImage:`url(${"https://salt.tikicdn.com/cache/w584/ts/banner/d8/f1/d4/9b4e7c1205c79279b362e0b360793a28.jpg"})`}}>
                                    
                                </div>
                                <div style={{width:"50%",height:"66%"}}>
                                   
                                </div>
                            </div>

                    </div>
                </div>
        </React.Fragment>
    )
}

export default HomePage