import { Col, Input, Row ,Button as AnButton} from 'antd'
import Grid from 'antd/lib/card/Grid'
import React from 'react'
import styled from 'styled-components'
import Logo from '../assets/images/logo.png'
import {FaUser} from 'react-icons/fa'
import {IoMdNotifications} from 'react-icons/io';
import {HiShoppingCart} from 'react-icons/hi';
import {AiOutlineMenu} from 'react-icons/ai';
const Header = styled.header`
    background-color:rgb(24, 158, 255);

`
const Button  = styled.button`
    outline:none;    
    color:white;
    background-color:transparent;
    height:100%;
    border-radius:5px;
    height:40px;
    border:2px solid #fff;
`
const {Search} = Input
const NavBar = (props:any) =>{
    return( 
        <React.Fragment>
            <Header>
                <div style={{display:'flex',flexWrap:'nowrap',justifyContent:'center'}}>
                    <div style={{width:"10%"}}>
                        <img src={Logo}     />
                    </div>
                    <div style={{display:'flex',alignItems:'center',width:'25%'}}>
                        <Search  placeholder="Tìm sản phẩm, danh mục hay thương hiệu mong muốn ..." size="large" />
                    </div>
                    <div style={{display:'flex',alignItems:'center',width:'35%'}}>
                        <div style={{width:"25%"}}>
                            <a href="javascript:void(0)" style={{display:'inline-flex',alignItems:'center'}}>
                                <div style={{height:"100%"}}>
                                <FaUser size={30}  style={{marginTop:'5px'}}/>
                                </div>
                                <div>
                                    Theo dõi <br/> đơn hàng
                                </div>
                            </a>
                        </div>
                        <div style={{width:"25%"}}>
                            <a href="javascript:void(0)" style={{display:'inline-flex',alignItems:'center'}}>
                                <div style={{height:"100%"}}>
                                <IoMdNotifications size={30}  style={{marginTop:'5px'}} color="#fff"/>
                                </div>
                                <div>
                                    Thông báo <br/> của tôi
                                </div>
                            </a>
                        </div>
                        <div style={{width:"25%"}}>
                            <a href="javascript:void(0)" style={{display:'inline-flex',alignItems:'center'}}>
                                <div style={{height:"100%"}}>
                                <FaUser size={30}  style={{marginTop:'5px'}}/>
                                </div>
                                <div>
                                    Đăng nhập <br/> Tài khoản   
                                </div>
                            </a>
                        </div>
                        <div style={{width:"25%"}}>
                            <a href="javascript:void(0)" style={{display:'inline-flex',alignItems:'center'}}>
                                <div style={{height:"100%"}}>
                                <FaUser size={30}  style={{marginTop:'5px'}}/>
                                </div>
                                <div>
                                    <Button style={{display:'flex',alignItems:'center',justifyContent:'space-around'}}>
                                        <HiShoppingCart size={20}/>
                                        Giỏ hàng
                                        <span style={{marginLeft:'2px',backgroundColor:"#fdd835",padding:'0px 6px',color:"black",borderRadius:'2px',height:'20px'}}>
                                            0
                                        </span>
                                    </Button>
                                </div>
                            </a>
                        </div>
                    </div>
                    
                </div>
                <div style={{display:'flex',justifyContent:'center'}}>
                        <div style={{width:'13%'}} >
                            <AnButton  style={{border:'none',backgroundColor:'transparent',color:'white',fontSize:'16px',lineHeight:'27px',display:'inline-flex',alignItems:'center'}} icon={<AiOutlineMenu size={25}/>}>Danh mục sản phẩm</AnButton>
                        </div>
                        <div style={{width:'10%'}}>
                            <a>Bạn muốn giao hàng tới đâu</a>                        
                        </div>
                        <div style={{width:'6%'}}>
                            <a>Sản phẩm <br/> bạn đã xem</a>                        
                        </div>
                        <div style={{width:'8%'}}>
                            <a>Hoàn tiền <br/> 15%</a>                        
                        </div>
                        <div style={{width:'8%'}}>
                            <a>Giao nhanh <br/> 2h & hôm sau</a>                        
                        </div>
                        <div style={{width:'8%'}}>
                            <a>Thực phẩm <br/> tươi sống</a>                        
                        </div>
                        <div style={{width:'8%'}}>
                            <a>Sản phẩm<br/> chính hiệu</a>                        
                        </div>
                        <div style={{width:'8%'}}>
                            <a>30 ngày <br/> đổi trả</a>                        
                        </div>
                    
                </div>
            </Header>
        </React.Fragment>
    )
}
export default NavBar;